class Bl_Op_Flag():
    FLAG_IK_MOVE_DRAG = True
    FLAG_OP_SHUTDOWN =  False
    FLAG_CAMERA_LOC_ALT = False
    FLAG_LCTRL_STATUS = False